import type { IconComponent } from "./types.cjs";
export declare const CheckCircle: IconComponent;
export default CheckCircle;
