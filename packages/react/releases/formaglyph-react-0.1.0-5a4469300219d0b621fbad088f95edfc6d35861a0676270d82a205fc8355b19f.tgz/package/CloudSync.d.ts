import type { IconComponent } from "./types.js";
export declare const CloudSync: IconComponent;
export default CloudSync;
