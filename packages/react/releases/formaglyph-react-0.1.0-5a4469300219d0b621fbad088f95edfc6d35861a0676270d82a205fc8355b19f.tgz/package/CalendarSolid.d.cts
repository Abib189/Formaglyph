import type { IconComponent } from "./types.cjs";
export declare const CalendarSolid: IconComponent;
export default CalendarSolid;
