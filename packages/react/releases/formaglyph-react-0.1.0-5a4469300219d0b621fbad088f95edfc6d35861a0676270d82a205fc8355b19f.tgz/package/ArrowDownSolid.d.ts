import type { IconComponent } from "./types.js";
export declare const ArrowDownSolid: IconComponent;
export default ArrowDownSolid;
