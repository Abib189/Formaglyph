import type { IconComponent } from "./types.cjs";
export declare const ChartBarsSolid: IconComponent;
export default ChartBarsSolid;
