import type { IconComponent } from "./types.js";
export declare const ArrowUp: IconComponent;
export default ArrowUp;
