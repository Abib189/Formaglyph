import type { IconComponent } from "./types.js";
export declare const ArrowLeft: IconComponent;
export default ArrowLeft;
