import type { IconComponent } from "./types.js";
export declare const Key: IconComponent;
export default Key;
