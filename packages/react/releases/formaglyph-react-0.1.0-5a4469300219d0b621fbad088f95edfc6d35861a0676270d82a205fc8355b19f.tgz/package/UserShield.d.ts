import type { IconComponent } from "./types.js";
export declare const UserShield: IconComponent;
export default UserShield;
