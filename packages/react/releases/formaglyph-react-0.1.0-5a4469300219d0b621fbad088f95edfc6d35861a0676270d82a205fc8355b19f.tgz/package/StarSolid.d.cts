import type { IconComponent } from "./types.cjs";
export declare const StarSolid: IconComponent;
export default StarSolid;
