import type { IconComponent } from "./types.js";
export declare const CloudUpload: IconComponent;
export default CloudUpload;
