import type { IconComponent } from "./types.js";
export declare const CopySolid: IconComponent;
export default CopySolid;
