import type { IconComponent } from "./types.js";
export declare const FolderSparkSolid: IconComponent;
export default FolderSparkSolid;
