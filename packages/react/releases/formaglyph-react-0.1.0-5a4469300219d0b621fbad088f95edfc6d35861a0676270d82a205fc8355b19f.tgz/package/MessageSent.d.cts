import type { IconComponent } from "./types.cjs";
export declare const MessageSent: IconComponent;
export default MessageSent;
