import type { IconComponent } from "./types.cjs";
export declare const MicrophoneSolid: IconComponent;
export default MicrophoneSolid;
