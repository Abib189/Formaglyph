import type { IconComponent } from "./types.js";
export declare const CheckCircle: IconComponent;
export default CheckCircle;
