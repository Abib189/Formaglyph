import type { IconComponent } from "./types.cjs";
export declare const CardCheckSolid: IconComponent;
export default CardCheckSolid;
