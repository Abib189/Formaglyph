import type { IconComponent } from "./types.js";
export declare const EditPencilSolid: IconComponent;
export default EditPencilSolid;
