import type { IconComponent } from "./types.cjs";
export declare const UserShield: IconComponent;
export default UserShield;
