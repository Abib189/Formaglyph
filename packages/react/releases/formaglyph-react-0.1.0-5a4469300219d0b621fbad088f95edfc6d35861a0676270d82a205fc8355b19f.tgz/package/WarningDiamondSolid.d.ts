import type { IconComponent } from "./types.js";
export declare const WarningDiamondSolid: IconComponent;
export default WarningDiamondSolid;
