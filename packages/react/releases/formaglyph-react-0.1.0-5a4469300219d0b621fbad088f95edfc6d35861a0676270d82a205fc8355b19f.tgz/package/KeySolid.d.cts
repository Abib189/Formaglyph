import type { IconComponent } from "./types.cjs";
export declare const KeySolid: IconComponent;
export default KeySolid;
