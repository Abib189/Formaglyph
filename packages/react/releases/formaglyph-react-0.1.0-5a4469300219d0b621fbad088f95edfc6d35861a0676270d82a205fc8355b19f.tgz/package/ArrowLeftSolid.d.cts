import type { IconComponent } from "./types.cjs";
export declare const ArrowLeftSolid: IconComponent;
export default ArrowLeftSolid;
