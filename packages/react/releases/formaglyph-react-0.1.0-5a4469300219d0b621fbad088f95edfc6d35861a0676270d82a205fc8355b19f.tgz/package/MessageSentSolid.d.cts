import type { IconComponent } from "./types.cjs";
export declare const MessageSentSolid: IconComponent;
export default MessageSentSolid;
