import type { IconComponent } from "./types.js";
export declare const Star: IconComponent;
export default Star;
