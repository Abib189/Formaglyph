import type { IconComponent } from "./types.cjs";
export declare const BellSolid: IconComponent;
export default BellSolid;
