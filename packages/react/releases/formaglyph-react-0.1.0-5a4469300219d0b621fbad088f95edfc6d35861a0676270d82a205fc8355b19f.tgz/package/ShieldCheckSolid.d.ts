import type { IconComponent } from "./types.js";
export declare const ShieldCheckSolid: IconComponent;
export default ShieldCheckSolid;
