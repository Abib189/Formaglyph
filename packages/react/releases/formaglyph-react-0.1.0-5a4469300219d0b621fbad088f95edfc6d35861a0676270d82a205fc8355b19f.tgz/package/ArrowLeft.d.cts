import type { IconComponent } from "./types.cjs";
export declare const ArrowLeft: IconComponent;
export default ArrowLeft;
