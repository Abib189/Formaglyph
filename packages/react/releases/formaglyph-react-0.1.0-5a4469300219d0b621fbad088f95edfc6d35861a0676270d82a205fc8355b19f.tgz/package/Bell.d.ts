import type { IconComponent } from "./types.js";
export declare const Bell: IconComponent;
export default Bell;
