import type { IconComponent } from "./types.cjs";
export declare const Star: IconComponent;
export default Star;
