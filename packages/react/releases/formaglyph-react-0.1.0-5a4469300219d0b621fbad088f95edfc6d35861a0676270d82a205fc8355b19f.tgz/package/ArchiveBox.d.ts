import type { IconComponent } from "./types.js";
export declare const ArchiveBox: IconComponent;
export default ArchiveBox;
