import type { IconComponent } from "./types.cjs";
export declare const CopySolid: IconComponent;
export default CopySolid;
