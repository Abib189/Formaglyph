import type { IconComponent } from "./types.js";
export declare const Trash: IconComponent;
export default Trash;
