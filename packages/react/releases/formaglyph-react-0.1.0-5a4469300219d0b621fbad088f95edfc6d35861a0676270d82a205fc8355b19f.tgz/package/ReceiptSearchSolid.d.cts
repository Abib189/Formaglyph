import type { IconComponent } from "./types.cjs";
export declare const ReceiptSearchSolid: IconComponent;
export default ReceiptSearchSolid;
