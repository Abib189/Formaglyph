import type { IconComponent } from "./types.cjs";
export declare const Unlock: IconComponent;
export default Unlock;
