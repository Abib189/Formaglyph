import type { IconComponent } from "./types.js";
export declare const Copy: IconComponent;
export default Copy;
