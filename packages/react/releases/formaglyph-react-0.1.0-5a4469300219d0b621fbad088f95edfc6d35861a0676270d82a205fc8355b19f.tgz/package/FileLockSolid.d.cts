import type { IconComponent } from "./types.cjs";
export declare const FileLockSolid: IconComponent;
export default FileLockSolid;
