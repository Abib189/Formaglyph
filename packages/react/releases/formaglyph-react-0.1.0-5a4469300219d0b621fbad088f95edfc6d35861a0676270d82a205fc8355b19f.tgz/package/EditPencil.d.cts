import type { IconComponent } from "./types.cjs";
export declare const EditPencil: IconComponent;
export default EditPencil;
