import type { IconComponent } from "./types.js";
export declare const ReceiptSearchSolid: IconComponent;
export default ReceiptSearchSolid;
