import type { IconComponent } from "./types.js";
export declare const ArrowRight: IconComponent;
export default ArrowRight;
