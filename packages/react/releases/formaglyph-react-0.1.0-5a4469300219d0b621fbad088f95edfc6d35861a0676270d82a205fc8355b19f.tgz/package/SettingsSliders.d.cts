import type { IconComponent } from "./types.cjs";
export declare const SettingsSliders: IconComponent;
export default SettingsSliders;
