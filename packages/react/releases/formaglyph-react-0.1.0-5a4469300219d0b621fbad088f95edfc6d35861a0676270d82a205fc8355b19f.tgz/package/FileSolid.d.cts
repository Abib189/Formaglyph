import type { IconComponent } from "./types.cjs";
export declare const FileSolid: IconComponent;
export default FileSolid;
