import type { IconComponent } from "./types.cjs";
export declare const HomeSolid: IconComponent;
export default HomeSolid;
