import type { IconComponent } from "./types.cjs";
export declare const ClockSolid: IconComponent;
export default ClockSolid;
