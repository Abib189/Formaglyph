import type { IconComponent } from "./types.cjs";
export declare const SearchSolid: IconComponent;
export default SearchSolid;
