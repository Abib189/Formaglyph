import type { IconComponent } from "./types.js";
export declare const ChartBars: IconComponent;
export default ChartBars;
