import type { IconComponent } from "./types.cjs";
export declare const LockSolid: IconComponent;
export default LockSolid;
