import type { IconComponent } from "./types.cjs";
export declare const ArrowRight: IconComponent;
export default ArrowRight;
