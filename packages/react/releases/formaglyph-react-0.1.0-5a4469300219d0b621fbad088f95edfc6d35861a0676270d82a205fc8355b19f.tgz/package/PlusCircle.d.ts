import type { IconComponent } from "./types.js";
export declare const PlusCircle: IconComponent;
export default PlusCircle;
