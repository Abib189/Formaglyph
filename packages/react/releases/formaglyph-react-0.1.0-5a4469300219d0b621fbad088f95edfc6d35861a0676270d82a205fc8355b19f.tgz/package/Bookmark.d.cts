import type { IconComponent } from "./types.cjs";
export declare const Bookmark: IconComponent;
export default Bookmark;
