import type { IconComponent } from "./types.js";
export declare const CheckCircleSolid: IconComponent;
export default CheckCircleSolid;
