import type { IconComponent } from "./types.cjs";
export declare const PlusCircleSolid: IconComponent;
export default PlusCircleSolid;
