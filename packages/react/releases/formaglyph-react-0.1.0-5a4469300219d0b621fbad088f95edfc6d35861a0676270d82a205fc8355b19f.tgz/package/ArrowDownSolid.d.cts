import type { IconComponent } from "./types.cjs";
export declare const ArrowDownSolid: IconComponent;
export default ArrowDownSolid;
