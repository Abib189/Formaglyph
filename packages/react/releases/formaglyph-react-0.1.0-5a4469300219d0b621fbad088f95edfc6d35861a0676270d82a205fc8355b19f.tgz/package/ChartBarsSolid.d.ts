import type { IconComponent } from "./types.js";
export declare const ChartBarsSolid: IconComponent;
export default ChartBarsSolid;
