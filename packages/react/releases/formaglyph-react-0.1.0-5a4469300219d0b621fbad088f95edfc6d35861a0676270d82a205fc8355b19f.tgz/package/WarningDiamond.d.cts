import type { IconComponent } from "./types.cjs";
export declare const WarningDiamond: IconComponent;
export default WarningDiamond;
