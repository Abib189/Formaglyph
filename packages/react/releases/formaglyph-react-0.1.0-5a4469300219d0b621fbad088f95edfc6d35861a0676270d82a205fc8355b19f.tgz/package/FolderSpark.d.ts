import type { IconComponent } from "./types.js";
export declare const FolderSpark: IconComponent;
export default FolderSpark;
