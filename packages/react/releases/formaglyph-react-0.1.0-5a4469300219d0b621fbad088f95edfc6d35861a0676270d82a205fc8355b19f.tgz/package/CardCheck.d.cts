import type { IconComponent } from "./types.cjs";
export declare const CardCheck: IconComponent;
export default CardCheck;
