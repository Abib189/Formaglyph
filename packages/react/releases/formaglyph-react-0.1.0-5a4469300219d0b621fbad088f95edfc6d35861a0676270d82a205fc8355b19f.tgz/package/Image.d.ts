import type { IconComponent } from "./types.js";
export declare const Image: IconComponent;
export default Image;
