import type { IconComponent } from "./types.cjs";
export declare const CloudUpload: IconComponent;
export default CloudUpload;
