import type { IconComponent } from "./types.cjs";
export declare const Search: IconComponent;
export default Search;
