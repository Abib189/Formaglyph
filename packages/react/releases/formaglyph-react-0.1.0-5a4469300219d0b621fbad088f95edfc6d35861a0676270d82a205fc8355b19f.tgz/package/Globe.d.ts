import type { IconComponent } from "./types.js";
export declare const Globe: IconComponent;
export default Globe;
