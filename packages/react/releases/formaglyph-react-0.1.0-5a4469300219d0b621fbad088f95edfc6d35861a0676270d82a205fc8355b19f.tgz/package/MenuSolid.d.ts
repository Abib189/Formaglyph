import type { IconComponent } from "./types.js";
export declare const MenuSolid: IconComponent;
export default MenuSolid;
