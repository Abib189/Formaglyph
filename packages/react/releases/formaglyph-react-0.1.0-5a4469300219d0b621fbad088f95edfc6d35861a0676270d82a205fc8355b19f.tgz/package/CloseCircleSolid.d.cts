import type { IconComponent } from "./types.cjs";
export declare const CloseCircleSolid: IconComponent;
export default CloseCircleSolid;
