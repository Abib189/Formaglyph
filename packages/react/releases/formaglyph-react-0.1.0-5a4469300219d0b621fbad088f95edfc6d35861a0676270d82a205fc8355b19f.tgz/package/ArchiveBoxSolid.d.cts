import type { IconComponent } from "./types.cjs";
export declare const ArchiveBoxSolid: IconComponent;
export default ArchiveBoxSolid;
