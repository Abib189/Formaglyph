import type { IconComponent } from "./types.cjs";
export declare const Home: IconComponent;
export default Home;
