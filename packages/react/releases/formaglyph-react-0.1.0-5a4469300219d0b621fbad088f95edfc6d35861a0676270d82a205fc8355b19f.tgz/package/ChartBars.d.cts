import type { IconComponent } from "./types.cjs";
export declare const ChartBars: IconComponent;
export default ChartBars;
