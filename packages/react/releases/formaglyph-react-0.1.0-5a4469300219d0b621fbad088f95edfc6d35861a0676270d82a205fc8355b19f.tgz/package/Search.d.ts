import type { IconComponent } from "./types.js";
export declare const Search: IconComponent;
export default Search;
