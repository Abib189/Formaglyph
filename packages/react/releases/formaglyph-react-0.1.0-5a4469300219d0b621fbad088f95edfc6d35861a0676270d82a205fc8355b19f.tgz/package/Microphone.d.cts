import type { IconComponent } from "./types.cjs";
export declare const Microphone: IconComponent;
export default Microphone;
