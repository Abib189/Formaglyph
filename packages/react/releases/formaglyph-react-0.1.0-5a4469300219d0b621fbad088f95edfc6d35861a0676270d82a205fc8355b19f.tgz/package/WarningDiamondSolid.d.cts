import type { IconComponent } from "./types.cjs";
export declare const WarningDiamondSolid: IconComponent;
export default WarningDiamondSolid;
