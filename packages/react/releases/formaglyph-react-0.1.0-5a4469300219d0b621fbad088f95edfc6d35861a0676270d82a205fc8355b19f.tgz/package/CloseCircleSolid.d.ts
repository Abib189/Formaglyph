import type { IconComponent } from "./types.js";
export declare const CloseCircleSolid: IconComponent;
export default CloseCircleSolid;
