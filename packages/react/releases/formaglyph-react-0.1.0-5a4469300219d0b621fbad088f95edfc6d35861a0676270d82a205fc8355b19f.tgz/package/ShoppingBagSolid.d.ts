import type { IconComponent } from "./types.js";
export declare const ShoppingBagSolid: IconComponent;
export default ShoppingBagSolid;
