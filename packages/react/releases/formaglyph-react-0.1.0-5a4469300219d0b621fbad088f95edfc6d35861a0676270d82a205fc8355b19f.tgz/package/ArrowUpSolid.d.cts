import type { IconComponent } from "./types.cjs";
export declare const ArrowUpSolid: IconComponent;
export default ArrowUpSolid;
