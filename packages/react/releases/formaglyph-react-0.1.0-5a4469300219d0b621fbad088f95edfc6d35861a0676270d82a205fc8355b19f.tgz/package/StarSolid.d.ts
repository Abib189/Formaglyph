import type { IconComponent } from "./types.js";
export declare const StarSolid: IconComponent;
export default StarSolid;
