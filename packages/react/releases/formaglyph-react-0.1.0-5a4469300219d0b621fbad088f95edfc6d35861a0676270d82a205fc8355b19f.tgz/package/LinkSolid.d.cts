import type { IconComponent } from "./types.cjs";
export declare const LinkSolid: IconComponent;
export default LinkSolid;
