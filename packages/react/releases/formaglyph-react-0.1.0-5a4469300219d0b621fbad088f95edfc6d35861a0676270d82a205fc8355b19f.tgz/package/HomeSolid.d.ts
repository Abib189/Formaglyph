import type { IconComponent } from "./types.js";
export declare const HomeSolid: IconComponent;
export default HomeSolid;
