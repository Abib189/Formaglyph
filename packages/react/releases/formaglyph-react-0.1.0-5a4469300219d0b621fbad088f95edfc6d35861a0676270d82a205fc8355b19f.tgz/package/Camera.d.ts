import type { IconComponent } from "./types.js";
export declare const Camera: IconComponent;
export default Camera;
