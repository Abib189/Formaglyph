import type { IconComponent } from "./types.js";
export declare const ExternalLinkSolid: IconComponent;
export default ExternalLinkSolid;
