import type { IconComponent } from "./types.cjs";
export declare const Clock: IconComponent;
export default Clock;
