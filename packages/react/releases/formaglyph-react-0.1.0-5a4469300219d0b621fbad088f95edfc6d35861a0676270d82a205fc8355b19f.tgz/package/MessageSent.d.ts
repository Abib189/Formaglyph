import type { IconComponent } from "./types.js";
export declare const MessageSent: IconComponent;
export default MessageSent;
