import type { IconComponent } from "./types.js";
export declare const Unlock: IconComponent;
export default Unlock;
