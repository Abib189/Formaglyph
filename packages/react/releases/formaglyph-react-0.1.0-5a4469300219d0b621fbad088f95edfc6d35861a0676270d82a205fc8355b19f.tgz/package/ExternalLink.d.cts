import type { IconComponent } from "./types.cjs";
export declare const ExternalLink: IconComponent;
export default ExternalLink;
