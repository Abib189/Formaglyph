import type { IconComponent } from "./types.js";
export declare const PlusCircleSolid: IconComponent;
export default PlusCircleSolid;
