import type { IconComponent } from "./types.cjs";
export declare const Mail: IconComponent;
export default Mail;
