/*
 * MIT License
 * 
 * Copyright (c) 2026 Formaglyph contributors
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
"use client";
// Formaglyph Core 0.2.0; ico_fg_048_globe; solid.
// Original SVG SHA-256: d816f90068b6540b6b3bd90032d3f1686bf683bf19a5ddf8e3233a4799dcd60d. Geometry and directionality are unchanged.
import { forwardRef, useId, type SVGProps } from "react";
export interface IconProps extends Omit<SVGProps<SVGSVGElement>, "children" | "dangerouslySetInnerHTML" | "title"> {
  size?: number | string;
  title?: string;
  titleId?: string;
  children?: never;
  dangerouslySetInnerHTML?: never;
}
const defaultSize = 24;
const defaultColor = "currentColor";
export const GlobeSolid = /* @__PURE__ */ forwardRef<SVGSVGElement, IconProps>(function GlobeSolid(
  { size = defaultSize, color = defaultColor, title, titleId, children: _children, dangerouslySetInnerHTML: _html, ...svgProps }, ref,
) {
  const generatedId = useId();
  const resolvedTitleId = titleId ?? generatedId;
  const named = Boolean(title || svgProps["aria-label"] || svgProps["aria-labelledby"]);
  return (
    <svg xmlns={"http://www.w3.org/2000/svg"} viewBox={"0 0 24 24"} fill={"currentColor"} stroke={"none"} fillRule={"evenodd"} {...svgProps} ref={ref} width={svgProps.width ?? size} height={svgProps.height ?? size} color={color}
      role={svgProps.role ?? (named ? "img" : undefined)}
      aria-hidden={svgProps["aria-hidden"] ?? (named ? undefined : true)}
      aria-labelledby={svgProps["aria-labelledby"] ?? (title && !svgProps["aria-label"] ? resolvedTitleId : undefined)}
      focusable={svgProps.focusable ?? false}>
      {title ? <title id={resolvedTitleId}>{title}</title> : null}
      <path d={"M11 2.1V8H8.5c.5-2.8 1.4-5 2.5-5.9zM13 2.1c1.1.9 2 3.1 2.5 5.9H13V2.1zM2.8 8a10 10 0 0 1 5.8-5.4A17.7 17.7 0 0 0 6.5 8H2.8zM15.4 2.6A10 10 0 0 1 21.2 8h-3.7a17.7 17.7 0 0 0-2.1-5.4zM2.2 10h4.1a25 25 0 0 0 0 4H2.2a10 10 0 0 1 0-4zM8.3 10H11v4H8.3a23 23 0 0 1 0-4zM13 10h2.7a23 23 0 0 1 0 4H13v-4zM17.7 10h4.1a10 10 0 0 1 0 4h-4.1a25 25 0 0 0 0-4zM2.8 16h3.7a17.7 17.7 0 0 0 2.1 5.4A10 10 0 0 1 2.8 16zM8.5 16H11v5.9c-1.1-.9-2-3.1-2.5-5.9zM13 16h2.5c-.5 2.8-1.4 5-2.5 5.9V16zM17.5 16h3.7a10 10 0 0 1-5.8 5.4c.9-1.4 1.6-3.3 2.1-5.4z"}></path>
    </svg>
  );
});
export default GlobeSolid;
