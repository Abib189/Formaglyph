/*
 * MIT License
 * 
 * Copyright (c) 2026 Formaglyph contributors
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
"use client";
// Formaglyph Core 0.2.0; ico_fg_039_image; solid.
// Original SVG SHA-256: 97bdad05fe7fe4415149e3b9d6de0d65434247e1b036203863fc15fd5fd054e1. Geometry and directionality are unchanged.
import { forwardRef, useId, type SVGProps } from "react";
export interface IconProps extends Omit<SVGProps<SVGSVGElement>, "children" | "dangerouslySetInnerHTML" | "title"> {
  size?: number | string;
  title?: string;
  titleId?: string;
  children?: never;
  dangerouslySetInnerHTML?: never;
}
const defaultSize = 24;
const defaultColor = "currentColor";
export const ImageSolid = /* @__PURE__ */ forwardRef<SVGSVGElement, IconProps>(function ImageSolid(
  { size = defaultSize, color = defaultColor, title, titleId, children: _children, dangerouslySetInnerHTML: _html, ...svgProps }, ref,
) {
  const generatedId = useId();
  const resolvedTitleId = titleId ?? generatedId;
  const named = Boolean(title || svgProps["aria-label"] || svgProps["aria-labelledby"]);
  return (
    <svg xmlns={"http://www.w3.org/2000/svg"} viewBox={"0 0 24 24"} fill={"currentColor"} stroke={"none"} fillRule={"evenodd"} {...svgProps} ref={ref} width={svgProps.width ?? size} height={svgProps.height ?? size} color={color}
      role={svgProps.role ?? (named ? "img" : undefined)}
      aria-hidden={svgProps["aria-hidden"] ?? (named ? undefined : true)}
      aria-labelledby={svgProps["aria-labelledby"] ?? (title && !svgProps["aria-label"] ? resolvedTitleId : undefined)}
      focusable={svgProps.focusable ?? false}>
      {title ? <title id={resolvedTitleId}>{title}</title> : null}
      <path d={"M5 2h14a3 3 0 0 1 3 3v14a3 3 0 0 1-3 3H5a3 3 0 0 1-3-3V5a3 3 0 0 1 3-3zm3 4a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM4 17v3h16v-1l-5-5-3 3-4-4-4 4z"}></path>
    </svg>
  );
});
export default ImageSolid;
