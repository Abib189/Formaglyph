/*
 * MIT License
 * 
 * Copyright (c) 2026 Formaglyph contributors
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
"use client";
// Formaglyph Core 0.1.0; ico_fg_007_file_lock; regular.
// Original SVG SHA-256: 7c04062310c637b88b5b29a8f929fcd669f7e3a266aef0ba4924a414ed8b3abf. Geometry and directionality are unchanged.
import { forwardRef, useId, type SVGProps } from "react";
export interface IconProps extends Omit<SVGProps<SVGSVGElement>, "children" | "dangerouslySetInnerHTML" | "title"> {
  size?: number | string;
  title?: string;
  titleId?: string;
  children?: never;
  dangerouslySetInnerHTML?: never;
}
const defaultSize = 24;
const defaultColor = "currentColor";
export const FileLock = /* @__PURE__ */ forwardRef<SVGSVGElement, IconProps>(function FileLock(
  { size = defaultSize, color = defaultColor, title, titleId, children: _children, dangerouslySetInnerHTML: _html, ...svgProps }, ref,
) {
  const generatedId = useId();
  const resolvedTitleId = titleId ?? generatedId;
  const named = Boolean(title || svgProps["aria-label"] || svgProps["aria-labelledby"]);
  return (
    <svg xmlns={"http://www.w3.org/2000/svg"} viewBox={"0 0 24 24"} fill={"none"} stroke={"currentColor"} strokeWidth={"1.75"} strokeLinecap={"round"} strokeLinejoin={"round"} {...svgProps} ref={ref} width={svgProps.width ?? size} height={svgProps.height ?? size} color={color}
      role={svgProps.role ?? (named ? "img" : undefined)}
      aria-hidden={svgProps["aria-hidden"] ?? (named ? undefined : true)}
      aria-labelledby={svgProps["aria-labelledby"] ?? (title && !svgProps["aria-label"] ? resolvedTitleId : undefined)}
      focusable={svgProps.focusable ?? false}>
      {title ? <title id={resolvedTitleId}>{title}</title> : null}
      <path d={"M5 3h8l4 4v4M13 3v4h4M5 3v18h7"}></path>
      <rect x={"12"} y={"14"} width={"8"} height={"6.5"} rx={"1.5"}></rect>
      <path d={"M14.5 14v-1.2a1.5 1.5 0 0 1 3 0V14"}></path>
    </svg>
  );
});
export default FileLock;
