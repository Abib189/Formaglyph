/*
 * MIT License
 * 
 * Copyright (c) 2026 Formaglyph contributors
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
"use client";
// Formaglyph Core 0.1.0; ico_fg_009_user_shield; solid.
// Original SVG SHA-256: 1dd2bd7daf28fa3146dfa32424503e8b0fa4b748f6a4ad08828d7f54b6d1fc05. Geometry and directionality are unchanged.
import { forwardRef, useId, type SVGProps } from "react";
export interface IconProps extends Omit<SVGProps<SVGSVGElement>, "children" | "dangerouslySetInnerHTML" | "title"> {
  size?: number | string;
  title?: string;
  titleId?: string;
  children?: never;
  dangerouslySetInnerHTML?: never;
}
const defaultSize = 24;
const defaultColor = "currentColor";
export const UserShieldSolid = /* @__PURE__ */ forwardRef<SVGSVGElement, IconProps>(function UserShieldSolid(
  { size = defaultSize, color = defaultColor, title, titleId, children: _children, dangerouslySetInnerHTML: _html, ...svgProps }, ref,
) {
  const generatedId = useId();
  const resolvedTitleId = titleId ?? generatedId;
  const named = Boolean(title || svgProps["aria-label"] || svgProps["aria-labelledby"]);
  return (
    <svg xmlns={"http://www.w3.org/2000/svg"} viewBox={"0 0 24 24"} fill={"currentColor"} stroke={"none"} fillRule={"evenodd"} {...svgProps} ref={ref} width={svgProps.width ?? size} height={svgProps.height ?? size} color={color}
      role={svgProps.role ?? (named ? "img" : undefined)}
      aria-hidden={svgProps["aria-hidden"] ?? (named ? undefined : true)}
      aria-labelledby={svgProps["aria-labelledby"] ?? (title && !svgProps["aria-label"] ? resolvedTitleId : undefined)}
      focusable={svgProps.focusable ?? false}>
      {title ? <title id={resolvedTitleId}>{title}</title> : null}
      <path d={"M9 3a4.5 4.5 0 1 1 0 9 4.5 4.5 0 0 1 0-9zM2 20a7 7 0 0 1 10.1-6.3c-.1.55-.1 1.15-.1 1.8 0 2.85 1.35 5 3.3 6.5H2v-2zM17 10l5 1.9v4.15c0 3.05-2.05 5.2-5 6.55-2.95-1.35-5-3.5-5-6.55V11.9L17 10zm-2.3 6.15 1.5 1.5 3.2-3.3-1.1-1.05-2.1 2.15-.4-.4-1.1 1.1z"}></path>
    </svg>
  );
});
export default UserShieldSolid;
