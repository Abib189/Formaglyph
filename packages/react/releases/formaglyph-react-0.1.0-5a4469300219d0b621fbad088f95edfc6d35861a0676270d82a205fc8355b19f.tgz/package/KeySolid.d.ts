import type { IconComponent } from "./types.js";
export declare const KeySolid: IconComponent;
export default KeySolid;
