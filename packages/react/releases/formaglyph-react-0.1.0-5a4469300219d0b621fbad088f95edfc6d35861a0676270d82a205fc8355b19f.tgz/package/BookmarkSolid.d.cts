import type { IconComponent } from "./types.cjs";
export declare const BookmarkSolid: IconComponent;
export default BookmarkSolid;
