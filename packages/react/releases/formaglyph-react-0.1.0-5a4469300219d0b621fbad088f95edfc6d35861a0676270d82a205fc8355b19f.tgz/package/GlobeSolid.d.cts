import type { IconComponent } from "./types.cjs";
export declare const GlobeSolid: IconComponent;
export default GlobeSolid;
