import type { IconComponent } from "./types.js";
export declare const MailSolid: IconComponent;
export default MailSolid;
