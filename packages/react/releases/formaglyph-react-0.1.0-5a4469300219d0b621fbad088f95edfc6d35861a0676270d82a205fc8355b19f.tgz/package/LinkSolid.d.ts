import type { IconComponent } from "./types.js";
export declare const LinkSolid: IconComponent;
export default LinkSolid;
