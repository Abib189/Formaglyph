import type { IconComponent } from "./types.js";
export declare const GridFourSolid: IconComponent;
export default GridFourSolid;
