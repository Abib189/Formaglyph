import type { IconComponent } from "./types.js";
export declare const ClockSolid: IconComponent;
export default ClockSolid;
