import type { IconComponent } from "./types.js";
export declare const TrashSolid: IconComponent;
export default TrashSolid;
