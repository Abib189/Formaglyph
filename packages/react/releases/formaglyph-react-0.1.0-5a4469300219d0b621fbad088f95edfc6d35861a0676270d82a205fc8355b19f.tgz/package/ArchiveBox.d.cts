import type { IconComponent } from "./types.cjs";
export declare const ArchiveBox: IconComponent;
export default ArchiveBox;
