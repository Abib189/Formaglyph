import type { IconComponent } from "./types.js";
export declare const CloseCircle: IconComponent;
export default CloseCircle;
