import type { IconComponent } from "./types.js";
export declare const FileLockSolid: IconComponent;
export default FileLockSolid;
