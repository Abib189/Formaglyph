import type { IconComponent } from "./types.cjs";
export declare const PlusCircle: IconComponent;
export default PlusCircle;
