import type { IconComponent } from "./types.js";
export declare const ArrowDown: IconComponent;
export default ArrowDown;
