import type { IconComponent } from "./types.cjs";
export declare const Copy: IconComponent;
export default Copy;
