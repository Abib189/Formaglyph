import type { IconComponent } from "./types.js";
export declare const MicrophoneSolid: IconComponent;
export default MicrophoneSolid;
