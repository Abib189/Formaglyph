import type { IconComponent } from "./types.js";
export declare const DownloadTraySolid: IconComponent;
export default DownloadTraySolid;
