import type { IconComponent } from "./types.cjs";
export declare const Bell: IconComponent;
export default Bell;
