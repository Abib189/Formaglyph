import type { IconComponent } from "./types.js";
export declare const CalendarSolid: IconComponent;
export default CalendarSolid;
