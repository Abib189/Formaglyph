import type { IconComponent } from "./types.cjs";
export declare const Image: IconComponent;
export default Image;
