import type { IconComponent } from "./types.js";
export declare const CardCheckSolid: IconComponent;
export default CardCheckSolid;
