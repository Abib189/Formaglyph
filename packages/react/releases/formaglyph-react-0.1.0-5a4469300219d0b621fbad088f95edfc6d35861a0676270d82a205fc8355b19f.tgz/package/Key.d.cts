import type { IconComponent } from "./types.cjs";
export declare const Key: IconComponent;
export default Key;
