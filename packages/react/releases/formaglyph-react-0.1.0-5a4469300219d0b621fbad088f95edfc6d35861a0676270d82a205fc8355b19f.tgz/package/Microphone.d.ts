import type { IconComponent } from "./types.js";
export declare const Microphone: IconComponent;
export default Microphone;
