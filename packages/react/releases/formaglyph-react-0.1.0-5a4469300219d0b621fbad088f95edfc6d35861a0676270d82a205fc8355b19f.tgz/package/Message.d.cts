import type { IconComponent } from "./types.cjs";
export declare const Message: IconComponent;
export default Message;
