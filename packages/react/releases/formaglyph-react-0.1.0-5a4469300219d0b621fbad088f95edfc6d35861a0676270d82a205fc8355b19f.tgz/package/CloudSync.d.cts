import type { IconComponent } from "./types.cjs";
export declare const CloudSync: IconComponent;
export default CloudSync;
