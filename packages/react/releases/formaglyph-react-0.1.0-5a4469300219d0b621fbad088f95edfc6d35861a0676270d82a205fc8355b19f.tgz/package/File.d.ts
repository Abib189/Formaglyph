import type { IconComponent } from "./types.js";
export declare const File: IconComponent;
export default File;
