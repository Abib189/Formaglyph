import type { IconComponent } from "./types.js";
export declare const Menu: IconComponent;
export default Menu;
