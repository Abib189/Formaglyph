import type { IconComponent } from "./types.js";
export declare const ReceiptSearch: IconComponent;
export default ReceiptSearch;
