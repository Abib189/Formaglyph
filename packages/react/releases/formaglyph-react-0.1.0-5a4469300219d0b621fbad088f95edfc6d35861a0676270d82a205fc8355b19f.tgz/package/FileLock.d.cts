import type { IconComponent } from "./types.cjs";
export declare const FileLock: IconComponent;
export default FileLock;
