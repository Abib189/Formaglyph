import type { IconComponent } from "./types.js";
export declare const WarningDiamond: IconComponent;
export default WarningDiamond;
