import type { IconComponent } from "./types.js";
export declare const MessageSolid: IconComponent;
export default MessageSolid;
