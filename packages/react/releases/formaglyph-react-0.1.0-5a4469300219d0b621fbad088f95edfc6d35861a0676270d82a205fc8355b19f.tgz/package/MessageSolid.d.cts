import type { IconComponent } from "./types.cjs";
export declare const MessageSolid: IconComponent;
export default MessageSolid;
