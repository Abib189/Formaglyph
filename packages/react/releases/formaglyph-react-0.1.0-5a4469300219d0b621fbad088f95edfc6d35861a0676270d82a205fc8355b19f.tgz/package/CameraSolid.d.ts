import type { IconComponent } from "./types.js";
export declare const CameraSolid: IconComponent;
export default CameraSolid;
