import type { IconComponent } from "./types.cjs";
export declare const CheckCircleSolid: IconComponent;
export default CheckCircleSolid;
