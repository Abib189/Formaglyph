import type { IconComponent } from "./types.cjs";
export declare const Link: IconComponent;
export default Link;
