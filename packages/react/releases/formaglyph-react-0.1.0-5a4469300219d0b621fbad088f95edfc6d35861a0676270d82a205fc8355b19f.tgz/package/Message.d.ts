import type { IconComponent } from "./types.js";
export declare const Message: IconComponent;
export default Message;
