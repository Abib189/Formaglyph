import type { IconComponent } from "./types.js";
export declare const DownloadTray: IconComponent;
export default DownloadTray;
