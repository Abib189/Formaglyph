import type { IconComponent } from "./types.js";
export declare const ArrowRightSolid: IconComponent;
export default ArrowRightSolid;
