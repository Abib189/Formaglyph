import type { IconComponent } from "./types.js";
export declare const SearchSolid: IconComponent;
export default SearchSolid;
