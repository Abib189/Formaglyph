import type { IconComponent } from "./types.cjs";
export declare const MailSolid: IconComponent;
export default MailSolid;
