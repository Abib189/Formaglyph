import type { IconComponent } from "./types.cjs";
export declare const Globe: IconComponent;
export default Globe;
