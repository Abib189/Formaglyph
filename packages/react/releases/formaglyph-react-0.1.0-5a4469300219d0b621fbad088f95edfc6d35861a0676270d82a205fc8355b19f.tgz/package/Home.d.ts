import type { IconComponent } from "./types.js";
export declare const Home: IconComponent;
export default Home;
