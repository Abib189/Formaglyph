import type { IconComponent } from "./types.cjs";
export declare const CreditCardSolid: IconComponent;
export default CreditCardSolid;
