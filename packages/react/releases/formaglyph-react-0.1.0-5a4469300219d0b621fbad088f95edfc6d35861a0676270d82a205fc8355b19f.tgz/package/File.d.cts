import type { IconComponent } from "./types.cjs";
export declare const File: IconComponent;
export default File;
