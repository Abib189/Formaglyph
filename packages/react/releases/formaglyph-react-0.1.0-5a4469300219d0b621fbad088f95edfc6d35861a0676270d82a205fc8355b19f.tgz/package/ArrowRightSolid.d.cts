import type { IconComponent } from "./types.cjs";
export declare const ArrowRightSolid: IconComponent;
export default ArrowRightSolid;
