import type { IconComponent } from "./types.js";
export declare const ImageSolid: IconComponent;
export default ImageSolid;
