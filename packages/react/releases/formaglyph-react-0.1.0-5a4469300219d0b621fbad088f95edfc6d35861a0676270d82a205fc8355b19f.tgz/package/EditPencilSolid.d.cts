import type { IconComponent } from "./types.cjs";
export declare const EditPencilSolid: IconComponent;
export default EditPencilSolid;
