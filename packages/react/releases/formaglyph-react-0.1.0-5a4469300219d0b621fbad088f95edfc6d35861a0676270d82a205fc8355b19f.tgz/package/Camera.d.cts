import type { IconComponent } from "./types.cjs";
export declare const Camera: IconComponent;
export default Camera;
