import type { IconComponent } from "./types.cjs";
export declare const ArrowUp: IconComponent;
export default ArrowUp;
