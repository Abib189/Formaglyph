import type { IconComponent } from "./types.cjs";
export declare const ExternalLinkSolid: IconComponent;
export default ExternalLinkSolid;
