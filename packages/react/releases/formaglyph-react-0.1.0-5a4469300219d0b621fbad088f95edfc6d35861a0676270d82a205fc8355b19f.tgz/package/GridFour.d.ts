import type { IconComponent } from "./types.js";
export declare const GridFour: IconComponent;
export default GridFour;
