import type { IconComponent } from "./types.js";
export declare const Mail: IconComponent;
export default Mail;
