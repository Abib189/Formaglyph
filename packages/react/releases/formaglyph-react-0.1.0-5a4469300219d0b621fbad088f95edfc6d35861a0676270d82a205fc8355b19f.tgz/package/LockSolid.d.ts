import type { IconComponent } from "./types.js";
export declare const LockSolid: IconComponent;
export default LockSolid;
