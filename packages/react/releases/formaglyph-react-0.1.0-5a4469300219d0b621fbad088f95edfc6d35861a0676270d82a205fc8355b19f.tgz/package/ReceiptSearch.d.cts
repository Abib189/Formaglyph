import type { IconComponent } from "./types.cjs";
export declare const ReceiptSearch: IconComponent;
export default ReceiptSearch;
