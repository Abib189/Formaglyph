import type { IconComponent } from "./types.cjs";
export declare const Lock: IconComponent;
export default Lock;
