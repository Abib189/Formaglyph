import type { IconComponent } from "./types.js";
export declare const GlobeSolid: IconComponent;
export default GlobeSolid;
