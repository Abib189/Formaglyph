import type { IconComponent } from "./types.js";
export declare const EditPencil: IconComponent;
export default EditPencil;
