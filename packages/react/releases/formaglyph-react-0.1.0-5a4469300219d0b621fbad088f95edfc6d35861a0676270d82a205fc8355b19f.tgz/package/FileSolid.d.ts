import type { IconComponent } from "./types.js";
export declare const FileSolid: IconComponent;
export default FileSolid;
