import type { IconComponent } from "./types.cjs";
export declare const CloseCircle: IconComponent;
export default CloseCircle;
