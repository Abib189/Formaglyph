import type { IconComponent } from "./types.js";
export declare const ShoppingBag: IconComponent;
export default ShoppingBag;
