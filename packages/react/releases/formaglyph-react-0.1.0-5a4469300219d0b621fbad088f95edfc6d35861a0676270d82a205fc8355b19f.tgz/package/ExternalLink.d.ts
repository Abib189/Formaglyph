import type { IconComponent } from "./types.js";
export declare const ExternalLink: IconComponent;
export default ExternalLink;
