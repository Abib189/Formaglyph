import type { IconComponent } from "./types.cjs";
export declare const Menu: IconComponent;
export default Menu;
