import type { IconComponent } from "./types.js";
export declare const UserShieldSolid: IconComponent;
export default UserShieldSolid;
