import type { IconComponent } from "./types.js";
export declare const Lock: IconComponent;
export default Lock;
