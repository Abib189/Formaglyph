import type { IconComponent } from "./types.js";
export declare const ArrowUpSolid: IconComponent;
export default ArrowUpSolid;
