import type { IconComponent } from "./types.js";
export declare const SettingsSlidersSolid: IconComponent;
export default SettingsSlidersSolid;
