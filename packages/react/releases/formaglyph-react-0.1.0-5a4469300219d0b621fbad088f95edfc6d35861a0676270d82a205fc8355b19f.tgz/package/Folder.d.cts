import type { IconComponent } from "./types.cjs";
export declare const Folder: IconComponent;
export default Folder;
