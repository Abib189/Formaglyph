import type { IconComponent } from "./types.js";
export declare const ShieldCheck: IconComponent;
export default ShieldCheck;
