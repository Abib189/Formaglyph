import type { IconComponent } from "./types.cjs";
export declare const TrashSolid: IconComponent;
export default TrashSolid;
