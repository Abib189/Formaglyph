import type { IconComponent } from "./types.js";
export declare const CreditCard: IconComponent;
export default CreditCard;
