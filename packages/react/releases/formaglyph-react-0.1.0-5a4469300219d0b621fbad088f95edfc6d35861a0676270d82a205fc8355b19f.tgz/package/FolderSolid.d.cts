import type { IconComponent } from "./types.cjs";
export declare const FolderSolid: IconComponent;
export default FolderSolid;
