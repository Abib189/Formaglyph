import type { IconComponent } from "./types.cjs";
export declare const CreditCard: IconComponent;
export default CreditCard;
