import type { IconComponent } from "./types.js";
export declare const Folder: IconComponent;
export default Folder;
