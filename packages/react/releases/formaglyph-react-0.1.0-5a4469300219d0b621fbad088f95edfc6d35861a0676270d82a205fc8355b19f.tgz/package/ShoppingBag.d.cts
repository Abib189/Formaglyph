import type { IconComponent } from "./types.cjs";
export declare const ShoppingBag: IconComponent;
export default ShoppingBag;
