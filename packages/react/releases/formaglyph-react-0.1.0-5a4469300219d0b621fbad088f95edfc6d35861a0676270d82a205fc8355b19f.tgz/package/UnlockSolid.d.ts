import type { IconComponent } from "./types.js";
export declare const UnlockSolid: IconComponent;
export default UnlockSolid;
