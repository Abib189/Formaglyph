import type { IconComponent } from "./types.js";
export declare const BellSolid: IconComponent;
export default BellSolid;
