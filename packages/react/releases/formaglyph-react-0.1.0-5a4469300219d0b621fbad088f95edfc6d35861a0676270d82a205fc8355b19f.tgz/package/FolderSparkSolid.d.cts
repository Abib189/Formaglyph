import type { IconComponent } from "./types.cjs";
export declare const FolderSparkSolid: IconComponent;
export default FolderSparkSolid;
