import type { IconComponent } from "./types.cjs";
export declare const ShoppingBagSolid: IconComponent;
export default ShoppingBagSolid;
