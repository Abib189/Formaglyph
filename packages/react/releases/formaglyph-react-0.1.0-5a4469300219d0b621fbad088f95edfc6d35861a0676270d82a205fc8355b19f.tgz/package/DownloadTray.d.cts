import type { IconComponent } from "./types.cjs";
export declare const DownloadTray: IconComponent;
export default DownloadTray;
