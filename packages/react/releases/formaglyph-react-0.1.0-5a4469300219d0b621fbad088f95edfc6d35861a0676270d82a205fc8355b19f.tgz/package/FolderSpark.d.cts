import type { IconComponent } from "./types.cjs";
export declare const FolderSpark: IconComponent;
export default FolderSpark;
