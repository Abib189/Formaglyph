import type { IconComponent } from "./types.js";
export declare const Link: IconComponent;
export default Link;
