import type { IconComponent } from "./types.cjs";
export declare const CloudSyncSolid: IconComponent;
export default CloudSyncSolid;
