import type { IconComponent } from "./types.cjs";
export declare const Calendar: IconComponent;
export default Calendar;
