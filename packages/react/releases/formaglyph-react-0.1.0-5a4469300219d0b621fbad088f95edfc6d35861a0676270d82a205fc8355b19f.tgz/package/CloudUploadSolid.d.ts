import type { IconComponent } from "./types.js";
export declare const CloudUploadSolid: IconComponent;
export default CloudUploadSolid;
