import type { IconComponent } from "./types.cjs";
export declare const MenuSolid: IconComponent;
export default MenuSolid;
