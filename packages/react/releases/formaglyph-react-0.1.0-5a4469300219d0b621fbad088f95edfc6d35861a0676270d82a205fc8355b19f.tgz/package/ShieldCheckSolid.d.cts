import type { IconComponent } from "./types.cjs";
export declare const ShieldCheckSolid: IconComponent;
export default ShieldCheckSolid;
