import type { IconComponent } from "./types.js";
export declare const FileLock: IconComponent;
export default FileLock;
