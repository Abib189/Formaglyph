import type { IconComponent } from "./types.cjs";
export declare const GridFourSolid: IconComponent;
export default GridFourSolid;
