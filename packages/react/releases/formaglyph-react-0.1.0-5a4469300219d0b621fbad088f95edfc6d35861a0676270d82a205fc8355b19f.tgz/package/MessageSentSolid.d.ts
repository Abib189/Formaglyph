import type { IconComponent } from "./types.js";
export declare const MessageSentSolid: IconComponent;
export default MessageSentSolid;
