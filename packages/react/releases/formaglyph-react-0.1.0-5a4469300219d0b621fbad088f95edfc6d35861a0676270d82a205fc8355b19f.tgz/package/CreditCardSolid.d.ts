import type { IconComponent } from "./types.js";
export declare const CreditCardSolid: IconComponent;
export default CreditCardSolid;
