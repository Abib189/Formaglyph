import type { IconComponent } from "./types.js";
export declare const Clock: IconComponent;
export default Clock;
