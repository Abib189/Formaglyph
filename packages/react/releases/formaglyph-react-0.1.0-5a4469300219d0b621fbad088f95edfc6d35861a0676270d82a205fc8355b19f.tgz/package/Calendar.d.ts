import type { IconComponent } from "./types.js";
export declare const Calendar: IconComponent;
export default Calendar;
