import type { IconComponent } from "./types.js";
export declare const Bookmark: IconComponent;
export default Bookmark;
