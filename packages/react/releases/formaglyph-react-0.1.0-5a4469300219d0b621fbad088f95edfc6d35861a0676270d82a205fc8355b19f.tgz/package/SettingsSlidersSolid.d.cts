import type { IconComponent } from "./types.cjs";
export declare const SettingsSlidersSolid: IconComponent;
export default SettingsSlidersSolid;
