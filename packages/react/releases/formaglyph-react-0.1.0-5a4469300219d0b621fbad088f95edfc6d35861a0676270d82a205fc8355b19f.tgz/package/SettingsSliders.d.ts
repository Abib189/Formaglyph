import type { IconComponent } from "./types.js";
export declare const SettingsSliders: IconComponent;
export default SettingsSliders;
