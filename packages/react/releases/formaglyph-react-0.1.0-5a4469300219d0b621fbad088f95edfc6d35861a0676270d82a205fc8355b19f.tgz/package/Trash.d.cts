import type { IconComponent } from "./types.cjs";
export declare const Trash: IconComponent;
export default Trash;
