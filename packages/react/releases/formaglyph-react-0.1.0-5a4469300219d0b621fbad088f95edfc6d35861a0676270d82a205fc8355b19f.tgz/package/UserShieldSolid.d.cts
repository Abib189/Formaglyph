import type { IconComponent } from "./types.cjs";
export declare const UserShieldSolid: IconComponent;
export default UserShieldSolid;
