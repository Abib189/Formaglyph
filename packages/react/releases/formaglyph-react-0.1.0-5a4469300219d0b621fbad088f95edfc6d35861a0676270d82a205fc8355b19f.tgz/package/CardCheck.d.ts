import type { IconComponent } from "./types.js";
export declare const CardCheck: IconComponent;
export default CardCheck;
