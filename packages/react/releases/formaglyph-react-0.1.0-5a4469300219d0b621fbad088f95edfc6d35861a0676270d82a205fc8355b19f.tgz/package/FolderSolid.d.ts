import type { IconComponent } from "./types.js";
export declare const FolderSolid: IconComponent;
export default FolderSolid;
