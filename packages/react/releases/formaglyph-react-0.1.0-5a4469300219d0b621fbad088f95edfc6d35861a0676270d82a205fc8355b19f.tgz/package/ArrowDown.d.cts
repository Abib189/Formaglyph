import type { IconComponent } from "./types.cjs";
export declare const ArrowDown: IconComponent;
export default ArrowDown;
