import type { IconComponent } from "./types.cjs";
export declare const DownloadTraySolid: IconComponent;
export default DownloadTraySolid;
