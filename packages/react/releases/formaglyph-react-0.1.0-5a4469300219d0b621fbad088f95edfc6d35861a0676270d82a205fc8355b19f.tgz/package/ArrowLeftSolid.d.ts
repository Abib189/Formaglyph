import type { IconComponent } from "./types.js";
export declare const ArrowLeftSolid: IconComponent;
export default ArrowLeftSolid;
