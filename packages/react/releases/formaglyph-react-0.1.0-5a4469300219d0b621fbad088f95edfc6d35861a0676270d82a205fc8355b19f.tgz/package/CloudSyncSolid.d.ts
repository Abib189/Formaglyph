import type { IconComponent } from "./types.js";
export declare const CloudSyncSolid: IconComponent;
export default CloudSyncSolid;
