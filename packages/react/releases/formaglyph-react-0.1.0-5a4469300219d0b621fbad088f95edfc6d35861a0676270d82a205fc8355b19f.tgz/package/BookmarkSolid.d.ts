import type { IconComponent } from "./types.js";
export declare const BookmarkSolid: IconComponent;
export default BookmarkSolid;
