import type { IconComponent } from "./types.cjs";
export declare const CloudUploadSolid: IconComponent;
export default CloudUploadSolid;
