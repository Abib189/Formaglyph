import type { IconComponent } from "./types.cjs";
export declare const CameraSolid: IconComponent;
export default CameraSolid;
