import type { IconComponent } from "./types.cjs";
export declare const GridFour: IconComponent;
export default GridFour;
