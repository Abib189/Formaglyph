import type { IconComponent } from "./types.js";
export declare const ArchiveBoxSolid: IconComponent;
export default ArchiveBoxSolid;
