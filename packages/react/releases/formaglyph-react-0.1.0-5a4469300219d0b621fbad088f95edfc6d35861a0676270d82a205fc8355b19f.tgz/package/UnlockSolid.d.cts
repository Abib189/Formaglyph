import type { IconComponent } from "./types.cjs";
export declare const UnlockSolid: IconComponent;
export default UnlockSolid;
