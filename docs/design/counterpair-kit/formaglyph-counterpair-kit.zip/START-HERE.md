# Formaglyph / Counterpair

Open docs/design/counterpair-kit/README.md for assets and guidance.
Open docs/design/formaglyph-glyph-workbench.figcraft in Figcraft; pages 07–09 contain the identity kit.
The repository-relative layout preserves handoff links. No production app is included.
